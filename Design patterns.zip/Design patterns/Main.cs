﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjOb
{
    public static class Program
    {
        public static void Main() 
        {
            CLI.RunApp();
            //MinExample.MinExample.Run();
        }
    }
}
