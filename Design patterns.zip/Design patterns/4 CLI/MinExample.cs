﻿using System.Diagnostics;
using System.Net.WebSockets;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace MinExample
{
    public class MinExample
    {
        [DataContractAttribute]
        public abstract class AbstractDog 
        {

        }

        public interface IAnimal
        {

        }

        [DataContract]
        public class Dog : IAnimal
        {
            [DataMember]
            private int ChildValue = 0;          
        }

        public static void Run()
        {
            Dog dog1 = new Dog();
            Dog dog2 = new Dog();
            Dog dog3 = new Dog();
            var list = new List<IAnimal>() { dog1, dog2, dog3 };

            string filename = "test";
            string cwd = Directory.GetCurrentDirectory();
            string path = Path.Combine(cwd, filename + ".xml");

            var serializer = new DataContractSerializer(typeof(List<IAnimal>),
                new Type[] {
                    typeof(Dog)
                });

            var settings = new XmlWriterSettings();
            settings.Indent = true;
            using (XmlWriter writer = XmlWriter.Create(path, settings))
            {
                serializer.WriteObject(writer, list);
            }

            OpenFile(path);
        }

        private static void OpenFile(string path)
        {
            using Process fileopener = new Process();

            fileopener.StartInfo.FileName = "explorer";
            fileopener.StartInfo.Arguments = "\"" + path + "\"";
            fileopener.Start();
        }
    }
}
